import AsyncStorage from '@react-native-async-storage/async-storage';
import * as FileSystem from 'expo-file-system/legacy';
import type { EditorDocument } from '../types/editor';
const KEY='memeshop.projects.v1';
export type SavedProject={id:string;name:string;updatedAt:number;thumbnail?:string;document:EditorDocument};
export async function listProjects():Promise<SavedProject[]> {try {return JSON.parse(await AsyncStorage.getItem(KEY)||'[]');}catch{return [];}}
export async function persistProject(project:SavedProject){const projects=await listProjects();const next=[project,...projects.filter(p=>p.id!==project.id)].sort((a,b)=>b.updatedAt-a.updatedAt);await AsyncStorage.setItem(KEY,JSON.stringify(next));}
export async function deleteProject(id:string){await AsyncStorage.setItem(KEY,JSON.stringify((await listProjects()).filter(p=>p.id!==id)));}
export async function durableImage(uri:string):Promise<string>{
 const root=FileSystem.documentDirectory+'memeshop-assets/';
 await FileSystem.makeDirectoryAsync(root,{intermediates:true});
 const path=root+Date.now()+'-'+Math.random().toString(36).slice(2)+'.png';
 await FileSystem.copyAsync({from:uri,to:path});return path;
}
