import React, { useRef, useState, useEffect } from 'react';
import { ActivityIndicator, Alert, Share, Pressable, SafeAreaView, ScrollView, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { ProjectsHome } from './ProjectsHome';
import { listProjects, persistProject, deleteProject, durableImage, pruneAssets, detachLibraryAssets, type SavedProject } from '../services/projects';
import { cropAndStraighten } from '../services/imageCrop';
import { CropPanel } from '../components/editor/CropPanel';
import { cropRect, cropLocalAngle, croppedGeometry, initialCrop, isCropNoop, pixelRect, type CropState } from '../utils/crop';
import { BrushControls } from '../components/editor/BrushControls';
import { Feather } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import * as MediaLibrary from 'expo-media-library';
import * as FileSystem from 'expo-file-system/legacy';
import * as ImageManipulator from 'expo-image-manipulator';
import Slider from '@react-native-community/slider';
import { LayersDrawer } from '../components/editor/LayersDrawer';
import { StickerLibrary } from '../components/editor/StickerLibrary';
import type { StickerAsset } from '../services/stickerLibrary';
import { PhotoCanvas, type PhotoCanvasHandle } from '../components/editor/PhotoCanvas';
import { EditorHeader, EditorToolbar, Sheet, SheetButton, type Tool } from '../components/editor/EditorChrome';
import { useEditorStore } from '../store/useEditorStore';
const colors = ['#ff508e','#ffffff','#111111','#25c5ff','#ffe05a','#65e89b'];
function MiniButton({ label, onPress }: {label:string;onPress:()=>void}) { return <Pressable onPress={onPress} style={styles.mini}><Text style={styles.miniText}>{label}</Text></Pressable>; }
export function EditorScreen() {
  const document = useEditorStore(s=>s.document);
  const [home,setHome]=useState(true);
  const [projects,setProjects]=useState<SavedProject[]>([]);
  const [projectId,setProjectId]=useState<string|null>(null);
  const [projectName,setProjectName]=useState('Proyecto sin título');
  const [crop,setCrop]=useState<CropState>(initialCrop);
  const [filterCategory,setFilterCategory]=useState('TODOS');
  const [filterPreset,setFilterPreset]=useState('Ninguno');
  useEffect(()=>{void listProjects().then(setProjects);},[]);
  useEffect(()=>{
    if(home||!document||!projectId)return;
    const timeout=setTimeout(()=>{void persistProject({id:projectId,name:projectName,updatedAt:Date.now(),document}).then(()=>listProjects().then(setProjects));},1200);
    return ()=>clearTimeout(timeout);
  },[document,projectId,projectName,home]);
  const openProject=async(p:SavedProject)=>{let doc=p.document;try{doc=(await detachLibraryAssets(doc)).document;}catch(e){console.warn(e);}useEditorStore.setState({document:doc,past:[],future:[],editBaseline:null});setProjectId(p.id);setProjectName(p.name);setTool(null);setHome(false);};
  const newProject=()=>{useEditorStore.getState().resetDocument();setProjectId(String(Date.now()));setProjectName('Proyecto sin título');setHome(false);setTool(null);};
  const goHome=async()=>{if(document&&projectId){await persistProject({id:projectId,name:projectName,updatedAt:Date.now(),document});setProjects(await listProjects());void pruneAssets();}setTool(null);setHome(true);};

  const setPhoto = useEditorStore(s=>s.setPhoto), addImage=useEditorStore(s=>s.addImage), addShape=useEditorStore(s=>s.addShape), addPaint=useEditorStore(s=>s.addPaint);
  const select=useEditorStore(s=>s.select), update=useEditorStore(s=>s.update), move=useEditorStore(s=>s.move), duplicate=useEditorStore(s=>s.duplicate), remove=useEditorStore(s=>s.remove);
  const undo=useEditorStore(s=>s.undo),redo=useEditorStore(s=>s.redo);
  const canUndo=useEditorStore(s=>s.past.length>0),canRedo=useEditorStore(s=>s.future.length>0);
  const [tool,setTool]=useState<Tool|null>(null);
  const [layersOpen,setLayersOpen]=useState(false);
  const [stickersOpen,setStickersOpen]=useState(false);
  const [brushColor,setBrushColor]=useState('#ff508e'),[brushSize,setBrushSize]=useState(20),[eraser,setEraser]=useState(false);
  const [busy,setBusy]=useState(false);
  const [exportError,setExportError]=useState<string|null>(null);
  const [imageLoading,setImageLoading]=useState(false);
  const [maskHardness,setMaskHardness]=useState(80);
  const [palette,setPalette]=useState<string[]>(colors);
  const [pickingColor,setPickingColor]=useState(false);
  const {width:screenWidth}=useWindowDimensions();
  const [maskMode,setMaskMode]=useState<'erase'|'restore'>('erase');
  const [maskSpread,setMaskSpread]=useState(35),[maskOpacity,setMaskOpacity]=useState(100);
  const [brushOpacity,setBrushOpacity]=useState(100),[brushHardness,setBrushHardness]=useState(100),[brushSpread,setBrushSpread]=useState(35);
  const canvas=useRef<PhotoCanvasHandle>(null);
  const selected=document?.layers.find(l=>l.id===document.selectedId);
  useEffect(()=>{if(tool!=='crop'&&tool!=='rotate'&&tool!=='perspective')setCrop(initialCrop);},[tool]);
  useEffect(()=>{setCrop(initialCrop);},[document?.selectedId]);
  const cropImage=selected?.type==='image'?selected:null;
  const cropPreview=tool==='crop'&&cropImage?{layerId:cropImage.id,rect:cropRect(crop,cropImage.width,cropImage.height,!!cropImage.flipX),angle:cropLocalAngle(crop,!!cropImage.flipX)}:null;
  async function importImage(replace=false) {
    try { setImageLoading(true); const result=await ImagePicker.launchImageLibraryAsync({mediaTypes:['images'],allowsEditing:false,quality:1});
      if(result.canceled||!result.assets.length)return;
      const a=result.assets[0];if(!a.width||!a.height)throw new Error('Imagen sin dimensiones');
      // Normalize HEIC/HEIF and other iPhone formats to a decoder-friendly PNG.
      const normalized = await ImageManipulator.manipulateAsync(a.uri, [], { format: ImageManipulator.SaveFormat.PNG });
      const photo={uri:await durableImage(normalized.uri),width:normalized.width,height:normalized.height,name:a.fileName??undefined};
      if(replace){setPhoto(photo);setTool(null);}else{addImage(photo);setTool('layers');}
    }catch(e){Alert.alert('Error al importar',String(e));}finally{setImageLoading(false);}
  }
  async function exportPreview(){
    if(!document||busy)return;
    setBusy(true);setExportError(null);
    try {
      // Snapshot is PNG in base64; write an actual .png before passing it to Photos.
      const base64=await canvas.current?.snapshotBase64();
      if(!base64)throw new Error('Skia no pudo generar la imagen. Espera a que termine de cargar.');
      if(!FileSystem.cacheDirectory)throw new Error('No se encontró el directorio temporal.');
      const file=`${FileSystem.cacheDirectory}memeshop-${Date.now()}.png`;
      await FileSystem.writeAsStringAsync(file,base64,{encoding:FileSystem.EncodingType.Base64});
      const info=await FileSystem.getInfoAsync(file);
      if(!info.exists || !info.size)throw new Error('El archivo PNG quedó vacío.');
      // iOS can return limited photo access; addOnly/writeOnly is sufficient for export.
      const permission=await MediaLibrary.requestPermissionsAsync(true);
      if(!permission.granted) {
        Alert.alert('Guardar imagen','Sin permiso para añadir fotos. Puedes compartir el PNG.',[
          {text:'Cancelar'}, {text:'Compartir',onPress:()=>{void Share.share({url:file,message:'Memeshop PNG'});}}
        ]);
        return;
      }
      try {
        await MediaLibrary.saveToLibraryAsync(file);
        Alert.alert('Guardado','Imagen PNG guardada en Fotos.');
      } catch(saveError) {
        setExportError(String(saveError));
        Alert.alert('No se pudo guardar en Fotos','El PNG se generó. Puedes compartirlo o guardarlo desde el menú del sistema.',[
          {text:'Cerrar'}, {text:'Compartir PNG',onPress:()=>{void Share.share({url:file,message:'Memeshop PNG'});}}
        ]);
      }
    } catch(e) {setExportError(String(e));Alert.alert('Error al exportar',String(e));}
    finally {setBusy(false);}
  }
  const refreshPalette=async()=>{try{const extracted=await canvas.current?.sampleColors();if(extracted?.length)setPalette(extracted);}catch(e){console.warn('No se pudo analizar el color',e);}};
  const choose=(next:Tool)=>{
    setPickingColor(false);
    if(next==='brush')void refreshPalette();
    if(next==='layers'){setLayersOpen(v=>!v);setTool(null);return;}
    if(next==='stickers'){setStickersOpen(true);setTool(null);return;}
    if(next==='images'){void importImage(false);return;}
    setLayersOpen(false);setTool(t=>t===next?null:next);
  };
  const insertSticker=async(asset:StickerAsset)=>{
    try{
      setImageLoading(true);
      // Copy into the project's own assets: deleting the sticker from the library must never break a project.
      const uri=await durableImage(asset.uri);
      addImage({uri,width:asset.width,height:asset.height,name:asset.name});setStickersOpen(false);
    }catch(e){Alert.alert('No se pudo insertar el sticker','El archivo del sticker no está disponible. Quizá fue eliminado o dañado.\n'+String(e));}
    finally{setImageLoading(false);}
  };
  const adjust=(key:'brightness'|'contrast'|'saturation',value:number)=>{
    if(!selected||selected.type!=='image')return;
    update(selected.id,{adjustments:{brightness:0,contrast:0,saturation:0,...selected.adjustments,[key]:Math.max(-1,Math.min(1,(selected.adjustments?.[key]??0)+value))}} as any);
  };
  const applyFilter=(name:string)=>{
    if(!selected||selected.type!=='image')return;
    const presets:Record<string,[number,number,number]>={Ninguno:[0,0,0],Vibrante:[.03,.16,.48],Vintage:[.08,-.12,-.38],Desaturado:[0,.06,-1],Brillante:[.18,.08,.12],Dramático:[-.08,.4,-.3],Pastel:[.12,-.18,-.15],Frío:[-.03,.06,-.12],Cálido:[.09,.06,.22]};
    const [brightness,contrast,saturation]=presets[name]||[0,0,0];
    update(selected.id,{adjustments:{brightness,contrast,saturation}} as any);setFilterPreset(name);
  };
  const normAngle=(a:number)=>Math.atan2(Math.sin(a),Math.cos(a));
  // A real mirror. Rendering is R(rotation)·F^flipX, so a mirror across the screen's vertical axis toggles flipX and negates
  // the rotation; across the horizontal axis it toggles flipX and maps rotation to π − rotation.
  const flip=(axis:'h'|'v')=>{
    if(!selected||selected.type!=='image'){Alert.alert('Voltear','Selecciona una capa de imagen para voltearla.');return;}
    update(selected.id,{flipX:!selected.flipX,rotation:normAngle(axis==='h'?-selected.rotation:Math.PI-selected.rotation)} as any);
  };
  const applyCrop=async()=>{
    if(!selected||selected.type!=='image'){Alert.alert('Recortar','Selecciona una capa de imagen para recortarla.');return;}
    const l=selected;
    const rect=cropRect(crop,l.width,l.height,!!l.flipX);
    if(isCropNoop(crop,rect)){setTool(null);return;}
    try{
      setBusy(true);
      const {px,frac}=pixelRect(rect,l.sourceWidth,l.sourceHeight);
      if(px.w<2||px.h<2)throw new Error('Recorte demasiado pequeño');
      const angle=cropLocalAngle(crop,!!l.flipX);
      let tmp:string,outW=px.w,outH=px.h;
      if(Math.abs(angle)<1e-4){
        const r=await ImageManipulator.manipulateAsync(l.uri,[{crop:{originX:px.x,originY:px.y,width:px.w,height:px.h}}],{format:ImageManipulator.SaveFormat.PNG});
        tmp=r.uri;outW=r.width;outH=r.height;
      }else{
        tmp=await cropAndStraighten(l.uri,l.width,l.height,frac,angle,px.w,px.h);
      }
      const uri=await durableImage(tmp);
      // Content stays in place; mask strokes are re-expressed in the new image's coordinates.
      const g=croppedGeometry(l,frac,angle);
      update(l.id,{uri,sourceWidth:outW,sourceHeight:outH,x:g.x,y:g.y,width:g.width,height:g.height,maskStrokes:g.maskStrokes} as any);
      // The previous file is not deleted here: undo still needs it. pruneAssets() removes it once the project is closed.
      setTool(null);setCrop(initialCrop);
    }catch(e){Alert.alert('Error de recorte',String(e));}finally{setBusy(false);}
  };
  if(home)return <SafeAreaView style={{flex:1,backgroundColor:'white'}}><ProjectsHome projects={projects} onOpen={openProject} onCreate={newProject} onDelete={id=>{void deleteProject(id).then(()=>{void pruneAssets();return listProjects().then(setProjects);});}}/></SafeAreaView>;
  return <SafeAreaView style={styles.root}>
    <EditorHeader back={()=>{void goHome();}} undo={undo} redo={redo} canUndo={canUndo} canRedo={canRedo} exportImage={exportPreview} busy={busy} eraseImage={document && selected?.type==='image' ? ()=>{setMaskMode('erase');setTool('mask');setLayersOpen(false);} : undefined} eraseActive={tool==='mask'}/>
    <View style={styles.workspace}>{document?<PhotoCanvas key={`${document.width}-${document.height}`} ref={canvas} document={document} mode={pickingColor?'eyedropper':tool==='brush'?'brush':tool==='mask'?'mask':'layer'} cropPreview={cropPreview} onPickColor={color=>{setBrushColor(color);setEraser(false);setPickingColor(false);setTool('brush');}} brush={{color:brushColor,size:brushSize,eraser,opacity:tool==='mask'?maskOpacity/100:brushOpacity/100,hardness:(tool==='mask'?maskHardness:brushHardness)/100,spread:tool==='mask'?maskSpread:brushSpread,restore:maskMode==='restore'}}/>:<View style={styles.empty}><Feather name="image" size={48} color="#aaa"/><Text style={styles.emptyTitle}>Comienza a crear</Text><MiniButton label="Elegir imagen" onPress={()=>importImage(true)}/></View>}{document && layersOpen && <LayersDrawer document={document} onClose={()=>setLayersOpen(false)}/>}</View>
    
    {document && tool && <View style={styles.sheetContainer}><Sheet title={{tools:'Herramientas',adjust:'Ajustes de imagen',brush:'Pincel',mask:'Borrar / restaurar',layers:'Capas',add:'Añadir elemento',transform:'Transformar capa',effects:'Efectos',crop:'Recortar',rotate:'Rotar',perspective:'Perspectiva',text:'Texto',stickers:'Stickers',images:'Imágenes'}[tool]} onClose={()=>setTool(null)}>
      {tool==='text' && <View style={styles.panel}><Text style={styles.help}>{tool==='effects'?'Los ajustes de brillo, contraste y saturación están disponibles en Herramientas → Ajustar. Los efectos avanzados llegarán después.':'Las capas de texto editable se implementarán en una próxima versión.'}</Text></View>}
      {tool==='effects' && <View style={{paddingBottom:16}}><ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginBottom:12}}>{['TODOS','COLORES','CÁMARA DIGITAL','ARTÍSTICOS'].map(c=><Pressable key={c} onPress={()=>setFilterCategory(c)} style={{padding:12,borderBottomWidth:filterCategory===c?2:0,borderBottomColor:'#ec3bdf'}}><Text style={{color:filterCategory===c?'#ef46df':'white',fontWeight:'600'}}>{c}</Text></Pressable>)}</ScrollView><ScrollView horizontal showsHorizontalScrollIndicator={false}>{['Ninguno','Vibrante','Vintage','Desaturado','Brillante','Dramático','Pastel','Frío','Cálido'].filter((n,i)=>filterCategory==='TODOS'||filterCategory==='COLORES'||filterCategory==='CÁMARA DIGITAL'&&i<6||filterCategory==='ARTÍSTICOS'&&i>=4).map(name=><Pressable key={name} onPress={()=>applyFilter(name)} style={{marginRight:9,width:92,alignItems:'center'}}><View style={{width:90,height:76,backgroundColor:name==='Vintage'?'#866d52':name==='Vibrante'?'#2e8a7a':name==='Dramático'?'#404049':name==='Frío'?'#42688a':name==='Cálido'?'#b87537':'#444',borderRadius:12,borderWidth:filterPreset===name?2:0,borderColor:'#ec3bdf',alignItems:'center',justifyContent:'center'}}><Feather name="image" size={27} color="white"/></View><Text numberOfLines={1} style={{color:'white',fontSize:11,marginTop:7}}>{name}</Text></Pressable>)}</ScrollView>{selected?.type!=='image'&&<Text style={styles.help}>Selecciona una imagen para aplicar filtros.</Text>}</View>}
      {['crop','rotate','perspective'].includes(tool) && <View style={{paddingBottom:10}}><View style={{flexDirection:'row',justifyContent:'space-around',paddingVertical:12}}>{(['crop','rotate','perspective'] as Tool[]).map((t)=><Pressable key={t} onPress={()=>setTool(t)} style={{padding:12,borderRadius:12,backgroundColor:tool===t?'#383838':'transparent'}}><Text style={{color:'white',fontSize:15}}>{t==='crop'?'Recortar':t==='rotate'?'Rotar':'Perspectiva'}</Text></Pressable>)}</View>{tool==='crop'&&<CropPanel crop={crop} setCrop={setCrop} onApply={()=>void applyCrop()} hasImage={!!cropImage} busy={busy}/>}{tool==='rotate'&&<><View style={styles.row}><MiniButton label="↶ 90°" onPress={()=>{if(selected)update(selected.id,{rotation:selected.rotation-Math.PI/2});}}/><MiniButton label="↷ 90°" onPress={()=>{if(selected)update(selected.id,{rotation:selected.rotation+Math.PI/2});}}/><MiniButton label="Voltear horizontal" onPress={()=>flip('h')}/><MiniButton label="Voltear vertical" onPress={()=>flip('v')}/></View><Text style={styles.field}>Ángulo · {Math.round((selected?.rotation??0)*180/Math.PI)}°</Text><Slider minimumValue={-180} maximumValue={180} step={1} value={(selected?.rotation??0)*180/Math.PI} onValueChange={v=>{if(selected)update(selected.id,{rotation:v*Math.PI/180});}} minimumTrackTintColor="#e946da" thumbTintColor="#fff"/></>}{tool==='perspective'&&selected?.type==='image'&&<><Text style={styles.field}>Convergencia horizontal (proyectiva)</Text><Slider minimumValue={-.5} maximumValue={.5} value={selected.perspectiveX??0} onValueChange={v=>update(selected.id,{perspectiveX:v} as any)} minimumTrackTintColor="#e946da" thumbTintColor="#fff"/><Text style={styles.field}>Convergencia vertical (proyectiva)</Text><Slider minimumValue={-.5} maximumValue={.5} value={selected.perspectiveY??0} onValueChange={v=>update(selected.id,{perspectiveY:v} as any)} minimumTrackTintColor="#e946da" thumbTintColor="#fff"/></>}</View>}
      {tool==='tools' && <View style={styles.grid}><SheetButton icon="crop" title="Recortar" onPress={()=>{setCrop(initialCrop);setTool('crop');}}/><SheetButton icon="sliders" title="Ajustar" onPress={()=>setTool('adjust')}/><SheetButton icon="move" title="Transformar" onPress={()=>setTool('transform')}/><SheetButton icon="layers" title="Capas" onPress={()=>setTool('layers')}/><SheetButton icon="edit-3" title="Dibujar" onPress={()=>{if(!selected||selected.type!=='paint')addPaint();setTool('brush');}}/><SheetButton icon="plus-square" title="Añadir" onPress={()=>setTool('add')}/></View>}
      {tool==='add' && <View style={styles.grid}><SheetButton icon="image" title="Imagen" onPress={()=>importImage(false)}/><SheetButton icon="edit-3" title="Pintura" onPress={()=>{addPaint();setTool('brush');}}/><SheetButton icon="square" title="Forma" onPress={()=>{addShape();setTool('layers');}}/><SheetButton icon="refresh-cw" title="Nueva foto" onPress={()=>importImage(true)}/></View>}
      {tool==='mask' && <BrushControls kind="mask" mode={maskMode} setMode={setMaskMode} size={brushSize} setSize={setBrushSize} spread={maskSpread} setSpread={setMaskSpread} opacity={maskOpacity} setOpacity={setMaskOpacity} hardness={maskHardness} setHardness={setMaskHardness} />}
      {tool==='brush' && <BrushControls kind="paint" spread={brushSpread} setSpread={setBrushSpread} size={brushSize} setSize={setBrushSize} opacity={brushOpacity} setOpacity={setBrushOpacity} hardness={brushHardness} setHardness={setBrushHardness} color={brushColor} setColor={c=>{setBrushColor(c);setEraser(false);}} eraser={eraser} setEraser={setEraser} palette={palette} onEyedropper={()=>{setPickingColor(true);setTool(null);}} onRefreshPalette={()=>{void refreshPalette();}} />}
      {tool==='layers' && <ScrollView style={styles.layers}>{[...document.layers].reverse().map(l=><Pressable key={l.id} onPress={()=>select(l.id)} style={[styles.layer,l.id===document.selectedId&&styles.layerActive]}><Feather name={l.type==='image'?'image':l.type==='paint'?'edit-3':'square'} size={18} color="#ddd"/><Text style={styles.layerName} numberOfLines={1}>{l.name}</Text><Text style={styles.value}>{Math.round(l.opacity*100)}%</Text><MiniButton label={l.visible?'◉':'○'} onPress={()=>update(l.id,{visible:!l.visible})}/></Pressable>)}</ScrollView>}
      {tool==='adjust' && <View style={styles.panel}>{selected?.type==='image'?(['brightness','contrast','saturation'] as const).map(k=><View key={k} style={styles.row}><Text style={styles.field}>{k==='brightness'?'Brillo':k==='contrast'?'Contraste':'Saturación'}</Text><MiniButton label="−" onPress={()=>adjust(k,-.1)}/><Text style={styles.value}>{(selected.adjustments?.[k]??0).toFixed(1)}</Text><MiniButton label="+" onPress={()=>adjust(k,.1)}/></View>):<Text style={styles.help}>Selecciona una capa de imagen para ajustar.</Text>}</View>}
      {tool==='transform' && <View style={styles.panel}>{selected?<><View style={styles.row}><MiniButton label="←" onPress={()=>update(selected.id,{x:selected.x-document.width*.025})}/><MiniButton label="→" onPress={()=>update(selected.id,{x:selected.x+document.width*.025})}/><MiniButton label="↑" onPress={()=>update(selected.id,{y:selected.y-document.height*.025})}/><MiniButton label="↓" onPress={()=>update(selected.id,{y:selected.y+document.height*.025})}/><MiniButton label="↺" onPress={()=>update(selected.id,{rotation:selected.rotation-Math.PI/12})}/><MiniButton label="↻" onPress={()=>update(selected.id,{rotation:selected.rotation+Math.PI/12})}/></View><View style={styles.row}><Text style={styles.field}>Tamaño</Text><MiniButton label="−" onPress={()=>update(selected.id,{width:selected.width*.9,height:selected.height*.9})}/><MiniButton label="+" onPress={()=>update(selected.id,{width:selected.width*1.1,height:selected.height*1.1})}/><Text style={styles.field}>Opacidad</Text><MiniButton label="−" onPress={()=>update(selected.id,{opacity:selected.opacity-.1})}/><Text style={styles.value}>{Math.round(selected.opacity*100)}%</Text><MiniButton label="+" onPress={()=>update(selected.id,{opacity:selected.opacity+.1})}/></View><View style={styles.row}><MiniButton label="Subir" onPress={()=>move(selected.id,1)}/><MiniButton label="Bajar" onPress={()=>move(selected.id,-1)}/><MiniButton label="Duplicar" onPress={()=>duplicate(selected.id)}/><MiniButton label="Eliminar" onPress={()=>remove(selected.id)}/></View></>:<Text style={styles.help}>Selecciona una capa para transformarla.</Text>}</View>}
    </Sheet></View>}
    {pickingColor && <Pressable style={styles.pickerBanner} onPress={()=>{setPickingColor(false);setTool('brush');}}><Text style={{color:'white'}}>Mantén pulsado y arrastra el cuentagotas · Toca aquí para cancelar</Text></Pressable>}
    {document && <EditorToolbar active={layersOpen?'layers':tool} onSelect={choose}/>}
    {document && stickersOpen && <StickerLibrary onInsert={insertSticker} onClose={()=>setStickersOpen(false)}/>}
    {(busy||imageLoading)&&<ActivityIndicator color="#e746d3" style={styles.busy}/>}
  </SafeAreaView>;
}
const styles=StyleSheet.create({root:{flex:1,backgroundColor:'#101010'},headerWrap:{position:'relative',zIndex:5},topEraser:{position:'absolute',right:105,top:11,alignItems:'center',justifyContent:'center',padding:5,borderRadius:9,minWidth:50},topEraserActive:{backgroundColor:'#5c2658'},topEraserText:{color:'#fff',fontSize:10},workspace:{flex:1,backgroundColor:'#1a1a1a'},empty:{flex:1,alignItems:'center',justifyContent:'center',gap:20},emptyTitle:{color:'#fff',fontSize:22,fontWeight:'600'},sheetContainer:{maxHeight:'49%'},grid:{flexDirection:'row',flexWrap:'wrap'},panel:{gap:12,paddingBottom:8},row:{flexDirection:'row',alignItems:'center',flexWrap:'wrap',gap:9},mini:{backgroundColor:'#303030',paddingHorizontal:13,paddingVertical:10,borderRadius:9},miniText:{color:'#fff',fontSize:12,fontWeight:'600'},field:{color:'#ddd',fontSize:13,minWidth:75},value:{color:'#ccc',fontSize:12},help:{color:'#aaa',fontSize:12},swatch:{height:30,width:30,borderRadius:15,borderWidth:3},layers:{maxHeight:260},layer:{flexDirection:'row',alignItems:'center',gap:10,padding:8,borderRadius:10},layerActive:{backgroundColor:'#42303e'},layerName:{flex:1,color:'#fff',fontSize:13},busy:{position:'absolute',top:80,alignSelf:'center'},pickerBanner:{backgroundColor:'#342137',padding:12,alignItems:'center'},maskShortcut:{position:'absolute',top:8,right:15,backgroundColor:'#29212d',borderRadius:18,paddingHorizontal:12,paddingVertical:9,flexDirection:'row',alignItems:'center',gap:6,borderWidth:1,borderColor:'#c343b7'}});
